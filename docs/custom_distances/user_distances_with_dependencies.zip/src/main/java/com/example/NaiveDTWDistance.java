
package com.example;

public class NaiveDTWDistance implements DistanceFunction {
    @Override
    public double compute(Object a, Object b) {
        double[] x = (double[]) a;
        double[] y = (double[]) b;
        int m = x.length;
        int n = y.length;
        double[][] dtw = new double[m + 1][n + 1];

        for (int i = 0; i <= m; i++) {
            for (int j = 0; j <= n; j++) {
                dtw[i][j] = Double.POSITIVE_INFINITY;
            }
        }
        dtw[0][0] = 0;

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                double cost = Math.abs(x[i - 1] - y[j - 1]);
                dtw[i][j] = cost + Math.min(Math.min(dtw[i - 1][j], dtw[i][j - 1]), dtw[i - 1][j - 1]);
            }
        }

        return dtw[m][n];
    }
}
