
package com.example;

public class EuclideanDistance implements DistanceFunction {
    @Override
    public double compute(Object a, Object b) {
        double[] x = (double[]) a;
        double[] y = (double[]) b;
        double sum = 0.0;
        for (int i = 0; i < x.length; i++) {
            double diff = x[i] - y[i];
            sum += diff * diff;
        }
        return Math.sqrt(sum);
    }
}
