
package com.example;

public interface DistanceFunction {
    double compute(Object a, Object b);
}
