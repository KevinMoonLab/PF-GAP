
package com.example;

import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;

public class SpectralDistance implements DistanceFunction {
    @Override
    public double compute(Object a, Object b) {
        double[][] matrixA = (double[][]) a;
        double[][] matrixB = (double[][]) b;

        RealMatrix realMatrixA = MatrixUtils.createRealMatrix(matrixA);
        RealMatrix realMatrixB = MatrixUtils.createRealMatrix(matrixB);

        EigenDecomposition eigA = new EigenDecomposition(realMatrixA);
        EigenDecomposition eigB = new EigenDecomposition(realMatrixB);

        double[] eigenvaluesA = eigA.getRealEigenvalues();
        double[] eigenvaluesB = eigB.getRealEigenvalues();

        double sum = 0.0;
        int len = Math.min(eigenvaluesA.length, eigenvaluesB.length);
        for (int i = 0; i < len; i++) {
            double diff = eigenvaluesA[i] - eigenvaluesB[i];
            sum += diff * diff;
        }

        return Math.sqrt(sum);
    }
}
